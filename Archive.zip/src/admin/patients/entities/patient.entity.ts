export class Patient {}
