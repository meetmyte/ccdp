export enum USER_TYPE {
  'PATIENT' = 1,
  'DOCTOR' = 2,
  'ADMIN' = 3,
  'STAFF' = 4,
}
